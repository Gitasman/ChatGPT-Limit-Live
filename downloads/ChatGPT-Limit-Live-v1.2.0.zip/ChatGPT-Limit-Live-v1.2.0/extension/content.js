(()=>{
'use strict';
const C=globalThis.LimitLiveCore;
const UI=globalThis.LimitLiveUI;
const t=UI.t;
let cfg=C.settings(),stopped=false,pollTimer,eventTimer,tickTimer,generationTimer,observer,wasGenerating=false,storageError='',lastAttempt=0;
let root,host,layout,refs={};
let lastPublished='';
function publicState(){return C.snapshot({...monitor.state,interval:cfg.interval});}
function publish(force=false){
  if(stopped||!alive())return;
  const state=publicState(),signature=JSON.stringify([state,document.hidden,C.badge(state).text]);
  if(!force&&signature===lastPublished)return;lastPublished=signature;
  try{const pending=chrome.runtime.sendMessage({type:'limit-live-snapshot',state,foreground:!document.hidden&&(document.hasFocus?.()??true)});pending?.catch(()=>{if(lastPublished===signature)lastPublished='';});}catch{}
}
const alive=()=>{try{return !!chrome.runtime.id}catch{return false}};
function stop(){stopped=true;clearTimeout(pollTimer);clearTimeout(eventTimer);clearInterval(tickTimer);clearTimeout(generationTimer);observer?.disconnect();layout?.destroy();monitor.invalidate();if(refs.orb)refs.orb.title=t.update;}
async function get(key){try{return(await chrome.storage.local.get(key))[key]}catch{return undefined}}
async function save(){try{await chrome.storage.local.set({limitLiveSettings:cfg});storageError='';}catch{storageError=t.notSaved;if(cfg.hidden)cfg.hidden=false;}render();publish();}
async function json(path,headers={},signal){
  if(!['/api/auth/session','/backend-api/wham/usage'].includes(path))throw new Error('Blocked endpoint');
  const timeout=AbortSignal.timeout(12000);
  const joined=new AbortController();const abort=()=>joined.abort();signal?.addEventListener('abort',abort,{once:true});timeout.addEventListener('abort',abort,{once:true});if(signal?.aborted)abort();
  try {
    const response=await fetch('https://chatgpt.com'+path,{method:'GET',credentials:'include',cache:'no-store',redirect:'error',headers:{accept:'application/json',...headers},signal:joined.signal});
    if(!response.ok){const value=response.headers.get('retry-after');const seconds=Number(value);const retryAfter=value?(Number.isFinite(seconds)?seconds*1000:Date.parse(value)-Date.now()):0;throw Object.assign(new Error('Usage HTTP error'),{status:response.status,retryAfter});}
    if(!response.headers.get('content-type')?.includes('application/json'))throw Object.assign(new Error('Unexpected format'),{code:'schema'});
    return await response.json();
  } finally {signal?.removeEventListener('abort',abort);timeout.removeEventListener('abort',abort);}
}
// Persist only an allowlisted usage schema. Never persist session, token, email or raw response.
function wire(n){
  const pool=rows=>Object.fromEntries(rows.map((w,i)=>[i?'secondary_window':'primary_window',{limit_window_seconds:w.seconds,used_percent:w.used,reset_at:w.resetAt===null?null:w.resetAt/1000}]));
  return {plan_type:n.plan,rate_limit:pool(n.windows),additional_rate_limits:n.additional.map(p=>({limit_name:p.name,rate_limit:pool(p.windows)}))};
}
async function usage(auth,signal){
  const bytes=new TextEncoder().encode(auth.key);const hash=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes))).map(x=>x.toString(16).padStart(2,'0')).join('');
  const run=async()=>{
    if(signal.aborted)throw new DOMException('Aborted','AbortError');
    const entries=await get('limitLiveCache')||{};const cached=entries[hash];
    if(cached&&cached.at<=Date.now()&&Date.now()-cached.at<20000){try{return {normalized:C.normalize(cached.raw),updatedAt:cached.at}}catch{}}
    const raw=await json('/backend-api/wham/usage',{'authorization':'Bearer '+auth.token,'chatgpt-account-id':auth.account},signal);
    const normalized=C.normalize(raw);const at=Date.now();
    if(signal.aborted)throw new DOMException('Aborted','AbortError');
    const next=Object.fromEntries(Object.entries(entries).filter(([,v])=>typeof v?.at==='number'&&at-v.at<3600000).sort((a,b)=>b[1].at-a[1].at).slice(0,7));next[hash]={raw:wire(normalized),at};
    try{await chrome.storage.local.set({limitLiveCache:next})}catch{/* Monitoring works without a cache. */}
    return {normalized,updatedAt:at};
  };
  return navigator.locks?navigator.locks.request('chatgpt-limit-live-usage-v1',{signal},run):run();
}
const monitor=new C.Monitor({session:signal=>json('/api/auth/session',{},signal),usage,changed:()=>{render();publish()}});
function request(delay=1000){
  if(stopped)return;
  // Coalesce page activity; a busy page cannot produce an unbounded request loop.
  if(eventTimer)return;
  eventTimer=setTimeout(()=>{eventTimer=null;refresh()},Math.max(delay,5000-(Date.now()-lastAttempt)));
}
async function refresh(){
  if(stopped)return;if(!alive()){stop();return;}
  clearTimeout(pollTimer);
  if(!navigator.onLine){monitor.emit({status:'offline'});schedule();return;}
  lastAttempt=Date.now();await monitor.refresh();schedule();
}
function schedule(){clearTimeout(pollTimer);if(!stopped)pollTimer=setTimeout(refresh,Math.max((document.hidden?120:cfg.interval)*1000,monitor.state.retryAt-Date.now()));}
function setText(node,value){if(node.textContent!==value)node.textContent=value;}
function setAttr(node,key,value){if(node.getAttribute?.(key)!==String(value))node.setAttribute(key,String(value));}
function render(){
  if(!root)return;
  host.dataset.theme=cfg.theme;host.dataset.collapsed=cfg.collapsed?'yes':'no';host.dataset.hidden=cfg.hidden?'yes':'no';
  if(host.style.getPropertyValue?.('--diameter')!==cfg.diameter+'px')host.style.setProperty('--diameter',cfg.diameter+'px');
  if(cfg.hidden)return;
  const state=publicState(),model=UI.orbModel(state),primary=state.usage?.windows.find(w=>w.kind==='weekly')||state.usage?.windows[0];
  setText(refs.orbPercent,model.percent);setText(refs.orbLabel,model.label);
  setText(refs.orbRemaining,model.stale&&primary?UI.t.stale:UI.t.remaining);
  setText(refs.orbReset,model.reset);
  setAttr(refs.ringProgress,'stroke-dashoffset',model.offset);
  setAttr(refs.ringProgress,'visibility',model.progress>0?'visible':'hidden');
  refs.orb.dataset.stale=model.stale?'yes':'no';refs.orb.dataset.tone=primary?.remaining<=10?'danger':primary?.remaining<=30?'warning':'normal';
  refs.orb.title=storageError||model.title;setAttr(refs.orb,'aria-label',model.title.replace(/\n/g,'. '));
  const status=state.usage&&model.stale?t.stale:UI.t[state.status]||t.loading;
  setText(refs.pill,primary?`${model.label} · ${model.percent}${model.stale?' · ?':''}`:status);
  refs.pill.title=model.title;
  layout?.update();
}
function setMode(mode){cfg=C.settings({...cfg,hidden:mode==='icon',collapsed:mode==='compact'});render();save();}
function mount(){
  if(stopped||host?.isConnected)return;
  if(!host){
    host=document.createElement('div');host.id='chatgpt-limit-live';host.style.cssText='position:fixed;z-index:2147483000;display:block';root=host.attachShadow({mode:'closed'});
    root.innerHTML=`<style>${UI.styles}</style><div class="pill-shell" id="pillShell" tabindex="0" role="group" aria-label="${UI.t.drag}"><div class="pill" id="pill" role="button" tabindex="0" aria-label="${UI.t.expand}"></div><button class="icon-button" id="pillHide" aria-label="${UI.t.hide}" title="${UI.t.hide}">${UI.svg('close')}</button></div><article class="orb" id="orb" tabindex="0" role="group" aria-label="${UI.t.drag}"><svg class="orb-ring" viewBox="0 0 120 120" aria-hidden="true"><circle class="ring-track" cx="60" cy="60" r="52"/><circle class="ring-progress" id="ringProgress" cx="60" cy="60" r="52" transform="rotate(-90 60 60)" pathLength="100" stroke-dasharray="100" stroke-dashoffset="100"/></svg><div class="orb-center"><span class="orb-label" id="orbLabel"></span><strong class="orb-number" id="orbPercent">…</strong><span class="orb-remaining" id="orbRemaining">${UI.t.remaining}</span><span class="orb-reset" id="orbReset"></span></div><span class="orb-status" aria-hidden="true"></span><button class="orb-hide" id="hide" aria-label="${UI.t.hide}" title="${UI.t.hide}">${UI.svg('close')}</button></article>`;
    for(const id of ['orb','orbPercent','orbLabel','orbRemaining','orbReset','ringProgress','pill'])refs[id]=root.getElementById(id);
    refs.pill.onclick=()=>setMode('panel');
    refs.pill.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();setMode('panel')}});
    for(const id of ['hide','pillHide'])root.getElementById(id).onclick=()=>setMode('icon');
    layout=new globalThis.LimitLiveLayout(host,[refs.orb,root.getElementById('pillShell')],()=>cfg,(patch,persist)=>{cfg=C.settings({...cfg,...patch});if(persist)save()});
  }
  document.documentElement.appendChild(host);render();
}
window.addEventListener('message',event=>{
  if(event.source!==window||event.origin!=='https://chatgpt.com'||event.data?.source!=='limit-live-v1')return;
  const {type,value}=event.data;
  if(type==='context'&&typeof value==='string'&&/^[\w-]{1,128}$/.test(value)&&monitor.hint!==value){monitor.invalidate(value);request(0)}
  else if(type==='session'){monitor.invalidate(monitor.hint);request(0)}
  else if(type==='activity')request(3000);
});
document.addEventListener('visibilitychange',()=>{if(!document.hidden)request(0);publish(true);schedule()});
window.addEventListener('focus',()=>{request(0);publish(true)});window.addEventListener('online',()=>request(0));window.addEventListener('offline',()=>{monitor.emit({status:'offline'});schedule()});
window.addEventListener('pageshow',()=>request(0));window.addEventListener('pagehide',()=>{clearTimeout(pollTimer);clearTimeout(eventTimer);eventTimer=null});
chrome.runtime.onMessage.addListener((message,_sender,respond)=>{
  if(message?.type==='limit-live-state'){respond(publicState());}
  if(message?.type==='limit-live-settings'){setMode('panel');respond({ok:true})}
});
chrome.storage.onChanged.addListener((changes,area)=>{if(area==='local'&&changes.limitLiveSettings){cfg=C.settings(changes.limitLiveSettings.newValue);render();publish();schedule()}});
(async()=>{
  cfg=C.settings(await get('limitLiveSettings'));mount();
  observer=new MutationObserver(()=>{
    if(!host?.isConnected)mount();
    if(generationTimer)return;
    generationTimer=setTimeout(()=>{generationTimer=null;if(stopped)return;
      const generating=!!document.querySelector('[data-testid="stop-button"],button[aria-label="Stop generating"]');
      if(wasGenerating&&!generating)request(1500);wasGenerating=generating;
    },250);
  });observer.observe(document.documentElement,{subtree:true,childList:true});
  tickTimer=setInterval(()=>{if(!alive()){stop();return}if(!document.hidden)render();publish()},15000);
  window.postMessage({source:'limit-live-query-v1'},location.origin);refresh();
})();
})();
